#' Title
#'
#' Main Description
#'
#' @docType package
#' @name lsrm12pl
#' @importFrom Rcpp evalCpp 
#' @importFrom MCMCpack procrustes
#' @useDynLib lsrm12pl
#' 
NULL
