#' 1pl model
#' 
#' 
#' @export
onepl = function(data, niter, nburn, nthin, nprint,
       jump_beta, jump_theta, pr_mean_beta, pr_sd_beta, pr_mean_theta, prior_a, prior_b){
  
  output <- onepl_cpp(data, niter, nburn, nthin, nprint,
                  jump_beta, jump_theta, pr_mean_beta, pr_sd_beta, 
                  prior_a, prior_b, pr_mean_theta)
  
  nsample <- nrow(data)
  nitem <- ncol(data)
  
  beta.estimate = apply(output$beta, 2, mean)
  theta.estimate = apply(output$theta, 2, mean)
  sigma_theta.estimate = mean(output$sigma_theta)
  
  return(list(beta_estimate  = beta.estimate,
              theta_estimate = theta.estimate,
              sigma_theta_estimate    = sigma_theta.estimate,
              beta           = output$beta,
              theta          = output$theta,
              theta_sd       = output$sigma_theta,
              accept_beta    = output$accept_beta,
              accept_theta   = output$accept_theta))
}
