#' 2pl model
#' 
#' 
#' @export
lsrm2pl = function(data, ndim, niter,nburn,nthin,nprint,
                   jump_beta, jump_theta, jump_alpha, jump_gamma, jump_z, jump_w,
                   pr_mean_beta, pr_sd_beta, prior_a,prior_b, pr_mean_theta,
                   pr_mean_gamma,pr_sd_gamma, pr_mean_alpha,  pr_sd_alpha){
  
  output <- twopl_lsrm(data, ndim, niter,nburn,nthin,nprint,
                       jump_beta, jump_theta, jump_alpha, jump_gamma, jump_z, jump_w,
                       pr_mean_beta, pr_sd_beta, prior_a,prior_b, pr_mean_theta,
                       pr_mean_gamma, pr_sd_gamma, pr_mean_alpha,  pr_sd_alpha)
  
  nsample <- nrow(data)
  nitem <- ncol(data)
  
  nmcmc = as.integer((niter - nburn) / nthin)
  max.address = min(which.max(output$map))
  w.star = output$w[max.address,,]
  z.star = output$z[max.address,,]
  w.proc = array(0,dim=c(nmcmc,nitem,ndim))
  z.proc = array(0,dim=c(nmcmc,nsample,ndim))
  #library(MCMCpack)
  for(iter in 1:nmcmc){
    z.iter = output$z[iter,,]
    if(iter != max.address) z.proc[iter,,] = procrustes(z.iter,z.star)$X.new
    else z.proc[iter,,] = z.iter
    
    w.iter = output$w[iter,,]
    if(iter != max.address) w.proc[iter,,] = procrustes(w.iter,w.star)$X.new
    else w.proc[iter,,] = w.iter
  }
  
  w.est = matrix(NA,nitem,ndim)
  for(i in 1:nitem){
    for(j in 1:ndim){
      w.est[i,j] = mean(w.proc[,i,j])
    }
  }
  z.est = matrix(NA,nsample,ndim)
  for(k in 1:nsample){
    for(j in 1:ndim){
      z.est[k,j] = mean(z.proc[,k,j])
    }
  }
  
  beta.estimate = apply(output$beta, 2, mean)
  theta.estimate = apply(output$theta, 2, mean)
  alpha.estimate = apply(output$alpha, 2, mean)
  sigma_theta.estimate = mean(output$sigma_theta)
  gamma.estimate = mean(output$gamma)
  
  return(list(beta_estimate  = beta.estimate,
              theta_estimate = theta.estimate,
              sigma_theta_estimate    = sigma_theta.estimate,
              gamma_estimate = gamma.estimate,
              alpha_estimate = alpha.estimate,
              z_estimate     = z.est,
              w_estimate     = w.est,
              beta           = output$beta,
              theta          = output$theta,
              theta_sd       = output$sigma_theta,
              gamma          = output$gamma,
              alpha          = output$alpha,
              z              = z.proc,
              w              = w.proc,
              accept_beta    = output$accept_beta,
              accept_theta   = output$accept_theta,
              accept_w       = output$accept_w,
              accept_z       = output$accept_z,
              accept_gamma   = output$accept_gamma,
              accept_alpha   = output$accept_alpha))
}