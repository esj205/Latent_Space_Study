#' 1pl interaction model normal version 
#' 
#' 
#' @export
intrm2pl_normal = function(data, niter, nburn, nthin, nprint,
                           jump_beta, jump_theta,jump_alpha,jump_delta,
                           pr_mean_beta, pr_sd_beta, 
                           pr_a_sigma,  pr_b_sigma,pr_a_th_sigma,pr_b_th_sigma, pr_mean_theta,
                           pr_mean_delta, pr_sd_delta){
  
  output <-  two_pl_intrm_cont(data, niter, nburn, nthin, nprint,
                               jump_beta, jump_theta,jump_alpha,jump_delta,
                               pr_mean_beta, pr_sd_beta, 
                               pr_a_sigma,  pr_b_sigma,pr_a_th_sigma,pr_b_th_sigma, pr_mean_theta,
                               pr_mean_delta, pr_sd_delta,pr_mean_alpha,pr_sd_alpha)
  
  
  
  beta.estimate = apply(output$beta, 2, mean)
  theta.estimate = apply(output$theta, 2, mean)
  alpha.estimate = apply(output$alpha, 2, mean)
  sigma_theta.estimate = mean(output$sigma_theta)
  delta.estimate = matrix(NA,nrow(data),ncol(data))
  nsample <- nrow(data)
  nitem <- ncol(data)
  
  for(k in 1:nsample){
    for(i in 1:nitem) delta.estimate[k,i] = mean(output$delta[,k,i])
  }
  
  #SVD
  ls.mean.delta = svd(delta.estimate, nu=ndim, nv=ndim)
  ls.mean.item  = ls.mean.delta$v
  ls.mean.sample = ls.mean.delta$u
  ls.mean.lambda = ls.mean.delta$d
  
  ls.item = array(NA, dim=c(nrow(output$beta),nitem,ndim))
  ls.sample = array(NA, dim=c(nrow(output$beta),nsample,ndim))
  ls.lambda = matrix(NA,nrow(output$beta),ndim)
  for(iter in 1:nrow(output$beta)){
    temp = svd(output$delta[iter,,], nu=ndim, nv=ndim)
    ls.item[iter,,] = temp$v
    ls.sample[iter,,] = temp$u
    ls.lambda[iter,] = temp$d[1:ndim]
  }
  
  return(list(beta_estimate  = beta.estimate,
                 theta_estimate = theta.estimate,
                 sigma_theta_estimate    = sigma_theta.estimate,
                 delta_estimate = delta.estimate,
                 alpha_estimate = alpha.estimate,
                 beta           = output$beta,
                 theta          = output$theta,
                 theta_sd       = output$sigma_theta,
                 delta          = output$delta,
                 alpha          = output$alpha,
                 accept_beta    = output$accept_beta,
                 accept_theta   = output$accept_theta,
                 accept_alpha   = output$accept_alpha,
                 ls_mean_item   = ls.mean.item,
                 ls_mean_sample = ls.mean.sample,
                 ls_mean_lambda = ls.mean.lambda,
                 ls_item        = ls.item,
                 ls_sample      = ls.sample,
                 ls_lambda      = ls.lambda))
  

}
