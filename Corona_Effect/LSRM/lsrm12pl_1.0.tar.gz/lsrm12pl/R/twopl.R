#' 2pl model
#' 
#' 
#' @export
twopl = function(data,niter,nburn,nthin,nprint,jump_beta,jump_theta,
                 jump_alpha,pr_mean_beta,pr_sd_beta,pr_mean_theta,prior_a,prior_b,
                 pr_mean_alpha,pr_sd_alpha){
  
  output <- two_pl(data,niter,nburn,nthin,nprint,jump_beta,jump_theta,
                   jump_alpha,pr_mean_beta,pr_sd_beta,pr_mean_theta,prior_a,prior_b,
                   pr_mean_alpha,pr_sd_alpha)
  
  nsample <- nrow(data)
  nitem <- ncol(data)
  
  beta.estimate = apply(output$beta, 2, mean)
  theta.estimate = apply(output$theta, 2, mean)
  alpha.estimate = apply(output$alpha, 2, mean)
  sigma_theta.estimate = mean(output$sigma_theta)
  
  return(list(beta_estimate  = beta.estimate,
              theta_estimate = theta.estimate,
              sigma_theta_estimate    = sigma_theta.estimate,
              alpha_estimate = alpha.estimate,
              beta           = output$beta,
              theta          = output$theta,
              theta_sd       = output$sigma_theta,
              alpha          = output$alpha,
              accept_beta    = output$accept_beta,
              accept_theta   = output$accept_theta,
              accept_alpha   = output$accept_alpha))
}
